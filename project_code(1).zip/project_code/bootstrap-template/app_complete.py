# app.py
from flask import Flask, Response, request
from os import path
import db_func
import numpy as np
import pandas as pd
#app = Flask(__name__)
#app = Flask(__name__, static_url_path = "/static", static_folder = "static")
from flask import Flask, Response, request, send_file
import ranking
import analytics

app = Flask(__name__, static_url_path="", static_folder="")
# @app.route('/')
# def hello_world():
#     return 'Hello World!'

# @app.route('/get_a', methods=["GET"])
# def get_a():
#    print(request.args.get("a"))
#    return "I get you! {}".format(request.args.get("a"))

# @app.route('/user/<user_id>')
# def get_user_id(user_id):
#    print(user_id)
#    return "I see you! {}".format(user_id)

@app.route('/')
def index():
   return send_file("index.html")

# """ @app.route('/charts')
# def index():
#    return send_file("index.html")

# @app.route('/tables')
# def index():
#    return send_file("index.html")
#  """
# @app.route('/predict', methods=['POST'])
# def predict():
#    data = request.json['data']   #需传有两个string的list
#    print(data)   
#    result = analyics.test(np.array(data))
#    return Response(result)

@app.route('/predict',methods=['POST'])
def predict_fun():
   if request.method=='POST':
      team = request.get_json()['option']
      
      # predict winning rate
      #result = analytics.test_again(team)
      result = analytics.test(team)
      
      # history rates for a,b team each
      df_T=db_func.read_db_list('T_Performance')
      history1=df_T.loc[df_T.team_name==team[0],'won_rate'].values.round(decimals=2)
      history2=df_T.loc[df_T.team_name==team[1],'won_rate'].values.round(decimals=2)
      
      # attributes
      list1=["average_kills","average_assists","minute_output","minute_hits","minute_money","average_smalldragon","average_tower_success","average_bigdragon"]
      attribute1=df_T.loc[df_T.team_name==team[0], list1].values.tolist()
      attribute2=df_T.loc[df_T.team_name==team[1], list1].values.tolist()

      s1=type_change(attribute1)
      s2=type_change(attribute2)
      print(s1[1:len(s1)-1])
      print(s2[1:len(s2)-1])
      return str(result)+','+str(history1)+','+str(history2)+','+s1[1:len(s1)-1]+','+s2[1:len(s1)-1]

   else :
      return render_template('index.html')


@app.route('/player', methods=['POST'])
def get_player():
   if request.method=='POST':
      input = request.get_json()['select']
      playerset=ranking.read_db_Player(input[0],input[1])
      s=type_change(playerset)
      return s
      # s = ""
      # for item in playerset:
      #    s = s + str(item)
      #    if playerset.index(item)!=len(playerset)-1:
      #       s=s+','
      # return s

@app.route('/rank', methods=['POST'])
def player_rank():
   player=request.get_json()['selectPlayer']
   team=request.get_json()['selectTeam']
   position=request.get_json()['selectPosition']
   
   rank=ranking.rank(team,player,position)
   radar1,radar2=ranking.show(team,player)

   #change list to string
   s3=type_change(rank)
   s4=type_change(radar1)
   s5=type_change(radar2)

   return s3+','+s4+','+s5


def type_change(ls):
   s=''
   for item in ls:
         s = s + str(item)
         if ls.index(item)!=len(ls)-1:
            s=s+','
   return s

@app.route('/table',methods=['POST'])
def display_player():
    #def table():
    #    return send_file("tables.html")
    #table()
    db_func.load_config()
    data_frame = db_func.read_db_list(tablename = "P_Performance")
    data_frame=data_frame.sort_values(by="player_name" , ascending=True)
    data_frame_new = pd.DataFrame(data_frame.values.T, index=data_frame.columns,columns=data_frame.index)
    result = data_frame_new.to_json()
    #rev=request.get_json()['city']
    #result=selcity(rev)
    return result     
    #return render_template('/table',result)
    #**字典名’


# if __name__ == '__main__':
#     app.run(threaded = True, debug = True)
if __name__ == '__main__':
    db_func.load_config(False)

    #if not db_func.check_table():
    #    db_func.setup_table(reconstruct = True)

    app.config['SEND_FILE_MAX_AGE_DEFAULT'] = 0
    app.run(threaded = True, debug = True,host='0.0.0.0',port=6150)