import numpy as np
import pandas as pd
import pymysql
from sklearn import datasets
from sklearn.decomposition import PCA
#from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.cluster import KMeans  
from xgboost import XGBClassifier
import db_func
from os import path
config = None

# OK
def get_train():
    """ Construct the training dataset"""
    conn, tunnel = db_func.create_db_conn()
    try:
        cur = conn.cursor()
        sql_comp_1 = """select Winner.win_comp_id comp_id, Winner.w_team a_team, Loser.l_team b_team, Winner.kills a_kills, Winner.assists a_assists, 
        Winner.minute_output a_minute_output, Winner.minute_hits a_minute_hits, Winner.minute_money a_minute_money,
        Winner.smalldragon a_smalldragon, Winner.tower_success a_tower_success, Winner.bigdragon a_bigdragon,
        Loser.kills b_kills, Loser.assists b_assists, Loser.minute_output b_minute_output, Loser.minute_hits b_minute_hits, Loser.minute_money b_minute_money,
        Loser.smalldragon b_smalldragon, Loser.tower_success b_tower_success, Loser.bigdragon b_bigdragon, Winner.score
        from Winner,Loser 
        where Winner.win_comp_id = Loser.lose_comp_id;"""
        sql_comp_2 = """select Loser.lose_comp_id comp_id, Loser.l_team a_team, Winner.w_team b_team, 
        Loser.kills a_kills, Loser.assists a_assists, Loser.minute_output a_minute_output, Loser.minute_hits a_minute_hits, Loser.minute_money a_minute_money,
        Loser.smalldragon a_smalldragon, Loser.tower_success a_tower_success, Loser.bigdragon a_bigdragon, 
        Winner.kills b_kills, Winner.assists b_assists,
        Winner.minute_output b_minute_output, Winner.minute_hits b_minute_hits, Winner.minute_money b_minute_money,
        Winner.smalldragon b_smalldragon, Winner.tower_success b_tower_success, Winner.bigdragon b_bigdragon, Loser.score
        from Winner,Loser where Winner.win_comp_id = Loser.lose_comp_id;"""
        cur.execute(sql_comp_1)
        cur.execute(sql_comp_2)
        # Construct the training set
        frame = [pd.read_sql(sql_comp_1, conn), pd.read_sql(sql_comp_2, conn)]
        df_comp = pd.concat(frame, ignore_index = True)
        conn.commit()        
    except Exception as e:
        print("get_train failed")
        print(e)

    conn.close()
    tunnel.close()

    # "history" column
    ## find the combinations of teams
    combine_list = []
    for i in range(len(df_comp)):
        combine = [df_comp.loc[i,"a_team"],df_comp.loc[i,"b_team"]]
        if combine not in combine_list: 
            combine_list.append(combine)
            
    ## denote history grades of each combination
    for i in range(len(combine_list)):
        current = df_comp[(df_comp["a_team"] == combine_list[i][0])&(df_comp["b_team"] == combine_list[i][1])]
        history = len(current[current["score"] == 1])/len(current)
        combine_list[i].append(history)

    ## add "history" column for training data
    for i in range(len(df_comp)):
        for j in range(len(combine_list)):
            if (df_comp.loc[i,"a_team"] == combine_list[j][0]) & (df_comp.loc[i,"b_team"] == combine_list[j][1]):
                df_comp.loc[i,"history"] = combine_list[j][2]

    X = pd.concat([df_comp.iloc[:, 1:19],df_comp.history], axis = 1)
    y = df_comp["score"] 

    return X, y

# OK
def test(team):
    """ Predict the competition result given team_a, team_b"""  
    team_a = team[0]
    team_b = team[1]
    # Get and normalize training X and y
    X, y = get_train()       
    X_1 = X.iloc[:,2:19]   

    # 3-sigma deal with outliers, use columns mean to fill NaN
    lower_limit = X_1.mean() - 3 * X_1.std()
    upper_limit = X_1.mean() + 3 * X_1.std()
    X_1 = X_1[(X_1 >= lower_limit) & (X_1 <= upper_limit)]

    for column in list(X_1.columns[X_1.isnull().sum() > 0]):
        mean_val = X_1[column].mean()
        X_1[column].fillna(mean_val, inplace=True)

    # Normalize X train
    X_1_normal = (X_1-X_1.min())/(X_1.max()-X_1.min())  
    
    # Construct the test X (one tuple)
    t_attr = ["average_kills","average_assists","minute_output","minute_hits","minute_money","average_smalldragon","average_tower_success","average_bigdragon"]
    a = pd.DataFrame(db_func.read_db_byt(team_a, "T_Performance"))    
    b = pd.DataFrame(db_func.read_db_byt(team_b, "T_Performance"))      
    a_attr = a[t_attr]
    b_attr = b[t_attr]
    history_col = history(team_a, team_b)        
    pre_X = pd.concat([a_attr, b_attr, history_col], axis = 1, ignore_index = True)                 

    # Normalize the X test
    for col in range(0, pre_X.shape[1] - 1):
        X_min = X_1.iloc[:,col].min()
        X_max = X_1.iloc[:,col].max()
        if pre_X.iloc[0,col] < X_min:
            pre_X.iloc[0,col] = 0
        elif pre_X.iloc[0,col] > X_max:
            pre_X.iloc[0,col] = 1
        else:
            pre_X.iloc[0,col] = (pre_X.iloc[0,col] - X_1.iloc[:, col].min())/(X_1.iloc[:, col].max() - X_1.iloc[:, col].min())

    # XGBoost
    # Prediction 
    pca = PCA(n_components = 4)
    pca.fit(X_1_normal)
    X_new = pca.transform(X_1_normal)
    clf = XGBClassifier(max_depth=8,min_child_weight=3,learning_rate=0.5)
    clf.fit(X_new, y)

    # Apply test data to do
    pre_X_new = pca.transform(pre_X)
    pre_y = clf.predict(pre_X_new)

    return pre_y[0]     #, pre_X.iloc[0, 6].round(decimals = 2), pre_X.iloc[0, 4].round(decimals = 2)

# OK
# def test_again(team):
#     """If test for a,b and b,a are the same, use average_tower_success to compare"""
#     team_a = team[0]
#     team_b = team[1]
#     if team_a==team_b:
#         result_1=None

#     result_1, avg_tower_1, money_1 = test(team_a, team_b)
#     result_2, avg_tower_2, money_2 = test(team_b, team_a)
#     if result_1 == result_2:
#         if avg_tower_1 > avg_tower_2:
#             return result_1
#         elif avg_tower_1 == avg_tower_2:
#             if money_1 >= money_2:
#                 return result_1
#             else:
#                 return abs(1- result_1)
#         else:
#             return abs(1 - result_1)
#     return result_1

def history(team_a, team_b):
    """ Construct the history grade of team a and team b"""
    X, y = get_train()
    X_team = X[["a_team","b_team","history"]]
    
    # history grade exists
    if X_team[(X_team["a_team"] == team_a) & (X_team["b_team"] == team_b)].notnull == True:
        history_df = X_team[(X_team["a_team"] == team_a)&(X_team["b_team"] == team_b)]
        history_grade = history_df.history

    # history grade does not exist
    else:
        df_level = set_level()
        level_1, level_2 = get_level(team_a, team_b)     
        history_grade = calculate_history(level_1, level_2)

    return pd.DataFrame([history_grade])

def set_level():
    """ Use K-means to get level of team a and team b"""
    
    # select T_performance in S9 and normalize
    df_t = db_func.read_db_list("T_Performance")
    t_attr = ["average_kills","average_assists","minute_output","minute_hits",
            "minute_money","average_smalldragon","average_tower_success","average_bigdragon"]
    df_t_norm = (df_t[t_attr] - df_t[t_attr].min())/(df_t[t_attr].max() - df_t[t_attr].min())
    df_t = pd.concat([df_t.team_name,df_t_norm,df_t.won_rate], axis = 1)

    # K-means to classify
    kmeans =  KMeans(n_clusters = 3, random_state = 0)   #n_clusters:number of cluster  
    kmeans.fit(df_t_norm)
    t_level = kmeans.labels_              
    df_t["level"] = t_level

    # Calculate history by level mean of won_rate 
    level_high = df_t.loc[df_t.team_name == "FPX","level"].values[0]
    level_low = df_t.loc[df_t.team_name == "GAM","level"].values[0]
    level_mid = df_t.loc[(df_t.level != level_high) & (df_t.level != level_low) ,"level"].values[0]

    df_t["level_rate"] = np.array(0)
    for i in range(len(df_t)):
        if df_t.loc[i,"level"] == level_high:
            df_t.loc[i,"level_rate"] = df_t.loc[df_t.level == level_high,"won_rate"].mean()
        elif df_t.loc[i,"level"] == level_low:
            df_t.loc[i,"level_rate"] = df_t.loc[df_t.level == level_low,"won_rate"].mean()
        else:
            df_t.loc[i,"level_rate"] = df_t.loc[df_t.level == level_mid,"won_rate"].mean()

    df_t = df_t.reset_index(drop=True)
    df_level = df_t[["team_name", "level", "level_rate"]]

    return df_level

def get_level(team_a, team_b):
    """ Get level of team a and team b"""
    df_level = set_level()
    level_1 = df_level.loc[df_level["team_name"] == team_a, "level"].values[0]
    level_2 = df_level.loc[df_level["team_name"] == team_b, "level"].values[0]
    return level_1, level_2

def calculate_history(level_1, level_2):
    """ Calculate new history grade if no old history grade"""    
    df_level = set_level()
    
    #level
    high = df_level.loc[df_level.team_name == "FPX","level"].values[0]
    low = df_level.loc[df_level.team_name == "GAM","level"].values[0]
    mid = df_level.loc[(df_level.level != high) & (df_level.level != low) ,"level"].values[0]
 
    #level ratio (0~1)
    if level_1 == level_2:
        history_grade = 0.5
    elif level_1 == high and level_2 == mid:
        history_grade = mid/(high + mid)
    elif level_1 == mid and level_2 == high:
        history_grade = high/(high + mid)
    elif level_1 == high and level_2 == low:
        history_grade = low/(high + low)
    elif level_1 == low and level_2 == high:
        history_grade = high/(high + low)
    elif level_1 == mid and level_2 == low:
        history_grade = low/(mid + low)
    elif level_1 == low and level_2 == mid:
        history_grade = mid/(mid + low)

    return history_grade



