# this is the model selection and feature selection file
# Import Packages
import pymysql
import pandas as pd
import numpy as np
import matplotlib
import matplotlib.pyplot as plt
import seaborn as sns
import sklearn
#from sklearn.model_selection import train_test_split

#data preprocessing
# Connect database
conn = pymysql.connect(
    host="120.27.144.199", 
    user="root", 
    password="ERG3010", 
    database="Group7", 
    charset="utf8")

# Get cursor to execute SQL
cursor = conn.cursor()

# execute SQL
sql_team_info = """select * from Team_info"""
sql_p_per = """select * from P_Performance"""
sql_t_per = """select * from T_Performance"""

sql_comp_1 = """select Winner.win_comp_id comp_id, Winner.w_team a_team, Loser.l_team b_team, Winner.kills a_kills, Winner.assists a_assists, 
    Winner.minute_output a_minute_output, Winner.minute_hits a_minute_hits, Winner.minute_money a_minute_money,
    Winner.smalldragon a_smalldragon, Winner.tower_success a_tower_success, Winner.bigdragon a_bigdragon,
    Loser.kills b_kills, Loser.assists b_assists, Loser.minute_output b_minute_output, Loser.minute_hits b_minute_hits, Loser.minute_money b_minute_money,
    Loser.smalldragon b_smalldragon, Loser.tower_success b_tower_success, Loser.bigdragon b_bigdragon, Winner.score
    from Winner,Loser 
    where Winner.win_comp_id = Loser.lose_comp_id;"""
sql_comp_2 = """select Loser.lose_comp_id comp_id, Loser.l_team a_team, Winner.w_team b_team, 
    Loser.kills a_kills, Loser.assists a_assists, Loser.minute_output a_minute_output, Loser.minute_hits a_minute_hits, Loser.minute_money a_minute_money,
    Loser.smalldragon a_smalldragon, Loser.tower_success a_tower_success, Loser.bigdragon a_bigdragon, 
    Winner.kills b_kills, Winner.assists b_assists,
    Winner.minute_output b_minute_output, Winner.minute_hits b_minute_hits, Winner.minute_money b_minute_money,
    Winner.smalldragon b_smalldragon, Winner.tower_success b_tower_success, Winner.bigdragon b_bigdragon, Loser.score
    from Winner,Loser 
    where Winner.win_comp_id = Loser.lose_comp_id;"""

cursor.execute(sql_team_info)
cursor.execute(sql_p_per)
cursor.execute(sql_t_per)
cursor.execute(sql_comp_1)
cursor.execute(sql_comp_2)

# Save as dataframe
df_team_info = pd.read_sql(sql_team_info, conn)
df_p_per = pd.read_sql(sql_p_per, conn)
df_t_per = pd.read_sql(sql_t_per, conn)
df_comp_1 = pd.read_sql(sql_comp_1, conn)
df_comp_2 = pd.read_sql(sql_comp_2, conn)

# Training Data Preprocessing
frame = [df_comp_1, df_comp_2]
df_comp = pd.concat(frame, ignore_index = True)

# "history" column
## find the combinations of teams
combine_list = []
for i in range(len(df_comp)):
    combine = [df_comp.loc[i,"a_team"],df_comp.loc[i,"b_team"]]
    if combine not in combine_list:
        combine_list.append(combine)

## denote history grades of each combination
for i in range(len(combine_list)):
    current = df_comp[(df_comp["a_team"] == combine_list[i][0])&(df_comp["b_team"] == combine_list[i][1])]
    history = len(current[current["score"] == 1])/len(current)
    combine_list[i].append(history)

## add "history" column for training data
for i in range(len(df_comp)):
    for j in range(len(combine_list)):
        if (df_comp.loc[i,"a_team"] == combine_list[j][0]) & (df_comp.loc[i,"b_team"] == combine_list[j][1]):
            df_comp.loc[i,"history"] = combine_list[j][2]



# Split into Training and Test Datasets; normalization
y = df_comp["score"]
X_1 = df_comp.iloc[:,3:19]
X_frame = [X_1,df_comp.history]
X = pd.concat(X_frame,axis = 1)
X_1_normal = (X_1-X_1.min())/(X_1.max()-X_1.min())  
X_normal_frame = [X_1_normal,df_comp.history]
X_normal = pd.concat(X_normal_frame,axis = 1)         ## X_normal for PCA...,X for deep learning 
#X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=123)

#plots for data preprocessing analysis
#to do

#model and its feature selection with PCA
#Logistic regression
#import packages
from sklearn import datasets
from sklearn.decomposition import PCA
from sklearn.pipeline import Pipeline
from sklearn.model_selection import GridSearchCV
from sklearn.linear_model import LogisticRegression
# Parameters of pipelines can be set using ‘__’ separated parameter names:
logistic=LogisticRegression()
print("logistic regression:")
pca = PCA()
pipe = Pipeline(steps=[('pca', pca), ('logistic', logistic)])

param_grid = {
    #'pca__n_components': [3],
    #'logistic__C':[100]
    'pca__n_components': range(1,18),
    'logistic__C':[1,10,100]
}
search = GridSearchCV(pipe, param_grid, iid=False, cv=5,scoring ='accuracy',n_jobs=8)
#search = GridSearchCV(pipe, param_grid, iid=False, cv=5,scoring ='roc_auc',n_jobs=8)
search.fit(X_normal, y)
print("Best parameter (CV accuracy=%0.3f):" % search.best_score_)
#print("Best parameter (CV roc_auc=%0.3f):" % search.best_score_)
print(search.best_params_)

# Plot the PCA spectrum
pca.fit(X_normal)

def plot_pca_result(pca,search):
    fig, (ax0, ax1) = plt.subplots(nrows=2, sharex=True, figsize=(6, 6))
    ax0.plot(pca.explained_variance_ratio_, linewidth=2)
    ax0.set_ylabel('PCA explained variance')
    ax0.axvline(search.best_estimator_.named_steps['pca'].n_components,
                linestyle=':', label='n_components chosen')
    ax0.legend(prop=dict(size=12))

# show the model's explained information(variance) by pca
def pca_explained(number):
    pca = PCA()
    pca.fit(X_normal, y)
    pca_explained = sum(pca.explained_variance_ratio_[0:number])
    print("explained information by pca : %0.3f" % pca_explained)

# For each number of components, find the best classifier
def plot_model_accurancy(search):
    results = pd.DataFrame(search.cv_results_)
    components_col = 'param_pca__n_components'
    best_clfs = results.groupby(components_col).apply(
        lambda g: g.nlargest(1, 'mean_test_score'))
    best_clfs.plot(x=components_col, y='mean_test_score', yerr='std_test_score',
                legend=False, ax=ax1)
    ax1.set_ylabel('Classification auccuracy(val)')
    ax1.set_xlabel('n_components')
    plt.tight_layout()
    plt.show()

def plot_model_auc(search):
    results = pd.DataFrame(search.cv_results_)
    components_col = 'param_pca__n_components'
    best_clfs = results.groupby(components_col).apply(
        lambda g: g.nlargest(1, 'mean_test_score'))
    best_clfs.plot(x=components_col, y='mean_test_score', yerr='std_test_score',
                legend=False, ax=ax1)
    ax1.set_ylabel('Classification roc_auc (val)')
    ax1.set_xlabel('n_components')
    plt.tight_layout()
    plt.show()

plot_pca_result(pca,search)
pca_explained(search.best_params_['pca__n_components'])
plot_model_accurancy(search)
#plot_model_auc(search)

#result
#Best parameter (CV roc_auc=0.998): {'logistic__C': 100, 'pca__n_components': 3}
#Best parameter (CV accuracy=0.986): {'logistic__C': 1, 'pca__n_components': 3}

#Logistic regression with gradient descent method
from sklearn.linear_model import SGDClassifier
logistic = SGDClassifier(loss='log', penalty='l2', early_stopping=True,
                         max_iter=10000, tol=1e-5, random_state=0)
print("Logistic regression with gradient descent method:")
pca = PCA()
pipe = Pipeline(steps=[('pca', pca), ('logistic', logistic)])

param_grid = {
    #'pca__n_components': [5],
    #'logistic__alpha': [0.0006951927961775605]
    'pca__n_components': range(1,18),
    'logistic__alpha': np.logspace(-4, 4, 20)
}
search = GridSearchCV(pipe, param_grid, iid=False, cv=5,scoring ='accuracy',n_jobs=8)
#search = GridSearchCV(pipe, param_grid, iid=False, cv=5,scoring ='roc_auc',n_jobs=8)
search.fit(X_normal, y)
print("Best parameter (CV accuracy=%0.3f):" % search.best_score_)
#print("Best parameter (CV roc_auc=%0.3f):" % search.best_score_)
print(search.best_params_)

# Plot the PCA spectrum
pca.fit(X_normal)

plot_pca_result(pca,search)
pca_explained(search.best_params_['pca__n_components'])
plot_model_accurancy(search)
#plot_model_auc(search)

#XGboost model
from xgboost import XGBClassifier
xgboost=XGBClassifier(n_jobs=8,early_stopping=True)
print("XGBOOST:")
pca = PCA()
pipe = Pipeline(steps=[('pca', pca), ('xgboost', xgboost)])

# Parameters of pipelines can be set using ‘__’ separated parameter names:
param_grid = {
   'pca__n_components': range(1,18),
   'xgboost__max_depth':range(3,10,1),
   'xgboost__min_child_weight':range(1,6,1),
   'xgboost_eta':[0.1,0.2,0.3,0.4,0.5]
}
# param_grid = {
#     'pca__n_components': [4],
#     'xgboost__max_depth':[8],
#     'xgboost__min_child_weight':[3],
#     'xgboost__learning_rate':[0.5]
# }
search = GridSearchCV(pipe, param_grid, iid=False, cv=5,scoring ='accuracy',n_jobs=8)
#search = GridSearchCV(pipe, param_grid, iid=False, cv=5,scoring ='roc_auc',n_jobs=8)
search.fit(X_normal, y)
print("Best parameter (CV accuracy=%0.3f):" % search.best_score_)
#print("Best parameter (CV roc_auc=%0.3f):" % search.best_score_)
print(search.best_params_)

# Plot the PCA spectrum
pca.fit(X_normal)
plot_pca_result(pca,search)
pca_explained(search.best_params_['pca__n_components'])
plot_model_accurancy(search)
#plot_model_auc(search)

#Decision Tree
from sklearn.tree import DecisionTreeClassifier
DTC = DecisionTreeClassifier()
print("Decision tree:")
pca = PCA()
pipe = Pipeline(steps=[('pca', pca), ('decisiontree', DTC)])

# Parameters of pipelines can be set using ‘__’ separated parameter names:
param_grid = {
    'pca__n_components': range(1,18),
    'decisiontree__max_depth':range(3,11,1),
    'decisiontree__min_weight_fraction_leaf':[i/10.0 for i in range(0,5)],
    'decisiontree__min_impurity_decrease':np.linspace(0, 0.2, 10)
}
#search = GridSearchCV(pipe, param_grid, iid=False, cv=5,scoring ='accuracy',n_jobs=8)
search = GridSearchCV(pipe, param_grid, iid=False, cv=5,scoring ='roc_auc',n_jobs=8)
search.fit(X_normal, y)
#print("Best parameter (CV accuracy=%0.3f):" % search.best_score_)
print("Best parameter (CV roc_auc=%0.3f):" % search.best_score_)
print(search.best_params_)

# Plot the PCA spectrum
pca.fit(X_normal)
plot_pca_result(pca,search)
pca_explained(search.best_params_['pca__n_components'])
plot_model_accurancy(search)
#plot_model_auc(search)

#Random forest
from sklearn.ensemble import RandomForestClassifier
rf=RandomForestClassifier()
print("Random Forest:")
pca = PCA()
pipe = Pipeline(steps=[('pca', pca), ('randomforest', rf)])

# Parameters of pipelines can be set using ‘__’ separated parameter names:
param_grid = {
    #'pca__n_components': [4],
    #'randomforest__max_depth':[9],
    #'randomforest__min_weight_fraction_leaf':[0]
    'pca__n_components': range(1,18),
    'randomforest__max_depth':range(3,11,1),
    'randomforest__min_weight_fraction_leaf':[i/10.0 for i in range(0,5)]
}
search = GridSearchCV(pipe, param_grid, iid=False, cv=5,scoring ='accuracy',n_jobs=8)
#search = GridSearchCV(pipe, param_grid, iid=False, cv=5,scoring ='roc_auc',n_jobs=8)
search.fit(X_normal, y)
print("Best parameter (CV accuracy=%0.3f):" % search.best_score_)
#print("Best parameter (CV roc_auc=%0.3f):" % search.best_score_)
print(search.best_params_)

# Plot the PCA spectrum
pca.fit(X_normal)
plot_pca_result(pca,search)
pca_explained(search.best_params_['pca__n_components'])
plot_model_accurancy(search)
#plot_model_auc(search)




