# Import Packages
import pymysql
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA 
import string
import db_func 


def find_s9_player():
    df_s9=db_func.read_db_list('P_Performance')
    print('df_s9',df_s9)
    s9_team=['C9','CG','DWG','FNC','FPX','G2','GRF','IG','RNG','SKT','SPY','TL']
    df_s9_4 = df_s9.loc[df_s9.team_name.isin(s9_team)]

    return df_s9_4

    player_s9=df_s9_4.player_name.values.tolist()
    np_s9=np.array(player_s9)
    print('player_s9:',player_s9)
    uniques=np.unique(np_s9)
    print('uniques:',uniques)
    return uniques
#find_s9_player()


def read_db_Player(teamname = "", position = "", playername = "", tablename = None):
 
    df_player=find_s9_player()

    if  len(teamname) != 0 and len(position) == 0 and len(playername) == 0:   
        result=df_player.loc[df_player.team_name==teamname,'player_name']

    elif len(teamname) == 0 and len(position) != 0 and len(playername) == 0:
        result=df_player.loc[df_player.position==position,'player_name']

    elif len(teamname) != 0 and len(position) != 0 and len(playername) == 0:
        df_player=df_player.loc[df_player.position==position,:]
        result=df_player.loc[df_player.team_name==teamname,'player_name']

    else:
        result = df_player.player_name
        
    result=result.values.tolist()
    np_result=np.array(result)
    result=np.unique(np_result)

    return result.tolist()


def find_rank(DF):
    df=DF.iloc[:,2:]
    norm = (df-df.min())/(df.max()-df.min()) 
    pca=PCA(n_components=1)     #加载PCA算法，设置降维后主成分数目为1
    fpc=pca.fit_transform(norm)#对样本进行降维 
    DF['fpc']=fpc
    result=[DF.player_name,DF.fpc]
    result = pd.concat(result, axis=1)
    result=result.sort_values(by="fpc" , ascending=False)
    order=result.player_name.values.tolist()
    return order

def rank(teamname,playername,position):
    df=db_func.read_db_one("P_Performance")
    df=df[df.position==position]
    if position == "ASSASSIN":
        df=df[['P_Performance_ID','player_name','KDA','MVP','plays_times','offered_rate','minute_economy','minute_hits', 'minute_damagedealt','damage_rate']]
    elif position == "MAGE":
        df=df[['P_Performance_ID','player_name','KDA','MVP','plays_times','offered_rate','minute_economy','minute_hits', 'minute_damagedealt','damage_rate']]
    elif position == "SUPPORT":
        df=df[['P_Performance_ID','player_name','KDA','MVP','plays_times','offered_rate','minute_economy','minute_damagetaken','damagetaken_rate','minute_wardsplaced','minute_wardkilled']]
    elif position == "ADC":
        df=df[['P_Performance_ID','player_name','KDA','MVP','plays_times','offered_rate','minute_economy','minute_damagedealt','damage_rate']]
    elif position == "TANK":
        df=df[['P_Performance_ID','player_name','KDA','MVP','plays_times','offered_rate','minute_economy','minute_damagedealt','damage_rate','minute_damagetaken','damagetaken_rate']]
    
    df_area = db_func.read_db_one("Team_info")
    #print(df_area)
    area=df_area.loc[df_area.team==teamname,"area"].values

    df_1=df[df.P_Performance_ID.str.contains("18C{}".format(area))] #      
    # print('df_1:',df_1)
    df_2=df[df.P_Performance_ID.str.contains("18X{}".format(area))]
    df_3=df[df.P_Performance_ID.str.contains("18S")]
    df_4=df[df.P_Performance_ID.str.contains("19C{}".format(area))]
    df_5=df[df.P_Performance_ID.str.contains("19X{}".format(area))]
    df_6=df[df.P_Performance_ID.str.contains("19S")]

    order1=find_rank(df_1)
    print('order1:',order1)
    order2=find_rank(df_2)
    order3=find_rank(df_3)
    order4=find_rank(df_4)
    order5=find_rank(df_5)
    order6=find_rank(df_6)

    order=[order1,order2,order3,order4,order5,order6]
    own_rank=[]

    for o in order:
        if playername in o:
            index=o.index(playername)+1
            r=(len(o)-index)/len(o)
        else:
            r=0
        own_rank.append(r)
    print('own_rank:',own_rank)
    return own_rank

rank('C9','Licorice','TANK')

# OK
def show(teamname, playername):
    """ get player data to fit the ld_chart"""
    df_p = db_func.read_db_set("P_Performance")
    p_attr = ["KDA","offered_rate","minute_damagedealt","minute_damagetaken","minute_economy"]
    df_team = df_p.loc[(df_p.team_name == teamname) & (df_p.player_name == playername), p_attr]
    if df_team.shape[0] > 1:
        df_team_2 = df_team.tail(2)
        p_1 = df_team_2.tail(1).values.tolist()
        p_2 = df_team_2.head(1).values.tolist()
    else:
        df_team_2 = df_team
        p_1 = df_team.values.tolist()
        p_2 = []

    return p_1[0], p_2[0] 










