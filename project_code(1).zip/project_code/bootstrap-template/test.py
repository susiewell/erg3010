
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from sklearn import datasets
from sklearn.decomposition import PCA
from sklearn.pipeline import Pipeline
from sklearn.model_selection import GridSearchCV
from sklearn.ensemble import RandomForestClassifier

def predict_score():
    pca = PCA(n_components = 4)
    pca.fit(X_normal)
    X_new = pca.transform(X_normal)
    rf = RandomForestClassifier()
    rf

