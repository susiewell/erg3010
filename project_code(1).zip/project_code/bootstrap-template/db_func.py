import pymysql
import pandas
import numpy as np
import json
import sys
from sshtunnel import SSHTunnelForwarder
from os import path
import pandas as pd
config = None

# OK, need default
def load_config(test = False, config_file = "config.json"):
    """Load the configuration from config.json, exit if fail"""

    global config
    with open(config_file, "r") as f:
        config = json.load(f)
    print("config:", config)

    for key in config:
        # Check if every configuration is set
        if config[key] == "":
            print("Please complete the config.json first!")
            sys.exit(1)
    #else:
        #config["default-k"] = int(config["default-k"])
        #if test:
            #config["default-suffix"] = config["test-suffix"]
            #config["default-table"] = "knn_"+config['test-suffix']
            #config["data-width"] = 3
            #config["data-dir"] += "_test"
        #else:
            #config["default-suffix"] = config["suffix"]
            #config["default-table"] = "knn_" + config["suffix"]
            #config["data-width"] = int(config["data-width"])

        print("Configuration Check success")

# OK, one dataset
def read_db_set(tablename = None):
    """Read one dataset from db"""

    # Set the default tablename 
    if tablename is None:
        tablename = config["default-table"]

    conn, tunnel = create_db_conn()
    result = None
    try:
        result = pd.read_sql("SELECT * FROM {};".format(str(tablename)), conn)
        if len(result) == 0:
            result = None

    except Exception as e:
        print("read_data_ failed")
        print(e)

    conn.close()
    tunnel.close()
    return result

# OK, one dataset, S9
def read_db_list(tablename = None):
    """Read all data from db contains info of S9."""

    # Set the default tablename 
    if tablename is None:
        tablename = config["default-table"]

    conn, tunnel = create_db_conn()
    result = None
    column_id = tablename + "_ID"
    try:
        #cur = conn.cursor()
        #result = pd.read_sql("SELECT * FROM %s where %s like '19S%' ;".format(%(tablename, column_id), conn)
        result = pd.read_sql("SELECT * FROM {} where {} like '19S%' ;".format(str(tablename), str(column_id)), conn)

        #conn.commit()
        if len(result) == 0:
            result = None

    except Exception as e:
        print("read_data_list failed")
        print(e)

    conn.close()
    tunnel.close()
    return result

# Team_info
def read_db_one(tablename = None):
    """Read all data from db."""
    # Set the default tablename 
    if tablename is None:
        tablename = config["default-table"]

    conn, tunnel = create_db_conn()
    result = None
    try:
        result = pd.read_sql("SELECT * FROM {};".format(str(tablename)), conn)

        if len(result) == 0:
            result = None

    except Exception as e:
        print("read_data_list failed")
        print(e)

    conn.close()
    tunnel.close()
    return result


# select by table and teamname
def read_db_byt(teamname, tablename = None):
    """Read a record from db. Return a tuple (id, actual_value, predict_value)."""

    # Set the default tablename
    if tablename is None:
        tablename = config["default-table"]

    conn, tunnel = create_db_conn()
    result = None

    column_id = tablename + "_ID"

    try:
        result = pd.read_sql("SELECT * FROM %s WHERE %s >= '19S' and team_name = '%s';"%(tablename, column_id, teamname), conn)
        conn.commit()
        if len(result) == 0:
            result = None

    except Exception as e:
        print("read_data_list failed")
        print(e)

    conn.close()
    tunnel.close()
    return result

# select the corresponding result
def read_db_Player(teamname = "", position = "", playername = "", tablename = None):
    """Read a record from db. Return a tuple (id, actual_value, predict_value)."""

    # Set the default tablename
    if tablename is None:
        tablename = config["default-table"]

    conn, tunnel = create_db_conn()
    result = None

    column_id = tablename + "_ID"
    print('enter')
    try: 
        if len(teamname) == 0 and len(position) == 0 and len(playername) == 0:
            data = pd.read_sql("SELECT * FROM %s WHERE %s >= '19S';"%(tablename, column_id), conn)
            result = data.player_name.values.tolist()
        elif  len(teamname) != 0 and len(position) == 0 and len(playername) == 0:   
            data = pd.read_sql("SELECT * FROM %s WHERE %s >= '19S' and team_name = '%s';"%(tablename, column_id, teamname), conn)
            result = data.player_name.values.tolist()
          
        elif len(teamname) == 0 and len(position) != 0 and len(playername) == 0:
            data = pd.read_sql("SELECT * FROM %s WHERE %s >= '19S' and position= '%s';"%(tablename, column_id, position), conn)
            result = data.player_name.values.tolist()
          
        elif len(teamname) != 0 and len(position) != 0 and len(playername) == 0:
            data = pd.read_sql("SELECT * FROM %s WHERE %s >= '19S' and team_name = '%s' and position= '%s';"%(tablename, column_id, teamname, position), conn)
            result = data.player_name.values.tolist()
         
        else:
            data = pd.read_sql("SELECT * FROM %s WHERE team_name = '%s' and position= '%s' and player_name = '%s';"%(tablename, teamname, position, playername), conn)
            result = data.player_name.values.tolist()
        
        conn.commit()
        if len(result) == 0:
            result = None

    except Exception as e:
        print("read_data_list failed")
        print(e)

    conn.close()
    tunnel.close()

    return result

# OK
def create_ssh_tunnel():
    """Create an SSH tunnel to access the database"""
    
    # Reference link: https://sshtunnel.readthedocs.io/en/latest/
    tunnel = SSHTunnelForwarder(
        (config['ip'], 22),
        ssh_username=config['username'],
        ssh_password=config["ssh-password"],
        remote_bind_address=('localhost', 3306),
    )

    tunnel.start() 
    print("SSH Connected") 
    return tunnel

# OK
def create_db_conn():
    """Create and return a SSH Tunnel for MySQL connection. Require manual close after usage."""
    
    # Using SSH Tunnel because professor has closed the 3306 port from external access.
    tunnel = create_ssh_tunnel()
    conn = pymysql.Connect(host=config['ip'],
                            port=tunnel.local_bind_port,
                            user=config['username'],
                            passwd=config['db-password'],
                            database=config['db'], 
                            charset="utf8")
    print("DB connected")
    return conn, tunnel

# test
load_config()
#result=read_db_Player(teamname="SPY",position="ADC")
#result=pd.DataFrame(result)
#print(result.iloc[:,0])
#result = read_db_list("T_Performance")
# result=read_db_byt("FPX", tablename = "T_Performance")
# print(result)

#data_frame_new = pd.DataFrame(data_frame.values.T, index=data_frame.columns,columns=data_frame.index)

# print(data_frame)
# print(data_frame_new.to_json())
#.tolist()
# result=read_db_Player('C9','ASSASSIN')
# print(result)